These are examples for using the C++ API of dReal. For SMT formulas or
hybrid system examples, please check the ../benchmarks directory.

To use the C++ API, you'll need to link with the dynamic library (the
prebuilt ones can be found in the releases) and include
`src/api/dreal.h` file.
