https://github.com/dreal-deps/ibex-lib

Patching:

https://github.com/ibex-team/ibex-lib/issues/306

Update:

The Waf build system is too old , need update to 1.9.1
https://waf.io/

Bulid:

/usr/bin/python2 ./waf configure --enable-shared --with-optim --with-affine --with-filib

/usr/bin/python2 ./waf install