/* include/capd/config-capdAux.h.  Generated from config-capdAux.h.in by configure.  */
/* include/capd/config-capdAux.h.in.  Generated from configure.ac by autoheader.  */

/* DEF_BUILD_DATE */
#define DEF_BUILD_DATE "20180119-1540"

/* DEF_BUILD_DISPLAY_NAME */
#define DEF_BUILD_DISPLAY_NAME ""

/* DEF_BUILD_ID */
#define DEF_BUILD_ID ""

/* DEF_BUILD_NUMBER */
#define DEF_BUILD_NUMBER ""

/* DEF_BUILD_TAG */
#define DEF_BUILD_TAG ""

/* DEF_JOB_NAME */
#define DEF_JOB_NAME ""

/* DEF_LIBRARY_VERSION */
#define DEF_LIBRARY_VERSION "1:0:0"

/* DEF_NODE_NAME */
#define DEF_NODE_NAME ""

/* DEF_SVN_REVISION_1 */
#define DEF_SVN_REVISION_1 ""

/* DEF_SVN_REVISION_2 */
#define DEF_SVN_REVISION_2 ""

/* DEF_SVN_REVISION_3 */
#define DEF_SVN_REVISION_3 ""

/* DEF_SVN_REVISION_4 */
#define DEF_SVN_REVISION_4 ""

/* DEF_SVN_URL_1 */
#define DEF_SVN_URL_1 ""

/* DEF_SVN_URL_2 */
#define DEF_SVN_URL_2 ""

/* DEF_SVN_URL_3 */
#define DEF_SVN_URL_3 ""

/* DEF_SVN_URL_4 */
#define DEF_SVN_URL_4 ""

/* DEF_VERSION */
#define DEF_VERSION "4.1.0"

/* Defined if the requested minimum BOOST version is satisfied */
/* #undef HAVE_BOOST */

/* Define to 1 if you have <boost/filesystem/path.hpp> */
/* #undef HAVE_BOOST_FILESYSTEM_PATH_HPP */

/* Define to 1 if you have <boost/regex.hpp> */
/* #undef HAVE_BOOST_REGEX_HPP */

/* Define to 1 if you have <boost/system/error_code.hpp> */
/* #undef HAVE_BOOST_SYSTEM_ERROR_CODE_HPP */

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* Use log4cxx */
/* #undef HAVE_LOG4CXX */

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/resource.h> header file. */
#define HAVE_SYS_RESOURCE_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory where libtool stores uninstalled libraries. */
#define LT_OBJDIR ".libs/"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "http://capd.ii.uj.edu.pl"

/* Define to the full name of this package. */
#define PACKAGE_NAME "capdAux"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "capdAux 4.1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "capdaux"

/* Define to the home page for this package. */
#define PACKAGE_URL "http://capd.ii.uj.edu.pl"

/* Define to the version of this package. */
#define PACKAGE_VERSION "4.1.0"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1
